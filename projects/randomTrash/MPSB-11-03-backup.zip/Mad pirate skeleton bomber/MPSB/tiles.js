
const tiles = [
    [0, 0],
    [1, 0], // 1 - Death
    [2, 0],
    [3, 0], // 3 - Trash Man
    [4, 0], // 4 - Camera
    [5, 0], // 5 - Skeleton
    [6, 0], // 6 - Interaction 
    [7, 0], // 7 - Jaymee
    [8, 0], // 8 - Esther 
    [9, 0], // 9 - VendingMachine 
    [10, 0], // 10 - Event 
    [0, 1], // 11 - Rock 
    [1, 1], // 12 - Skateboard 
]